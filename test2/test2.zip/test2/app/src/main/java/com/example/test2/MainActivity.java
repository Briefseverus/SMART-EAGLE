//package com.example.test2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
/*
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseStorage storage=FirebaseStorage.getInstance();
        StorageReference imageRef = storage.getReferenceFromUrl("gs://smarteagle-a3f43.appspot.com/home/pi/Pictures").child("2023-02-22 04:24:48.200065.jpg");
        ImageView imageview=findViewById(R.id.);
        GlideApp.with(this).load(imageRef).into(imageview);
    }
}*/